# NANMUDHALVAN_TUESDAYBATCH_PROJECT_FILES

PROJECT CREATED BY : Aarthi A
AU510421205001
5104 Arunai engineering college.
                    



LOGIN DETAILS:


UNAME: admin


Password:admin




#Project Running steps:

python manage.py makemigrations

python manage.py migrate

python manage.py createsuperuser

python manage.py runserver
